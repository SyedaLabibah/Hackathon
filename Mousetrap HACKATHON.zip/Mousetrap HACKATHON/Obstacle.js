class Brick{
    constructor(){

    }

    HorizontalBrick(){
        if (World.frameCount % 30 === 0) {
            HB.x = 200
            console.log("jwenudinuoei")
          }
        }
    }
